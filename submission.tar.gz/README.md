# Tetris

A simple implementation of the classic game Tetris.

## Controls
- <kbd>Enter</kbd>: start
- <kbd>&larr;</kbd>: move piece left
- <kbd>&rarr;</kbd>: move piece right
- <kbd>&darr;</kbd>: move piece down
- <kbd>&uarr;</kbd>: drop piece
- <kbd>Z</kbd>: rotate counterclockwise
- <kbd>X</kbd>: rotate clockwise
- <kbd>Backspace</kbd>: reset