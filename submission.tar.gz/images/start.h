/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 start start.png 
 * Time-stamp: Tuesday 04/05/2022, 02:51:20
 * 
 * Image Information
 * -----------------
 * start.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef START_H
#define START_H

extern const unsigned short start[38400];
#define START_SIZE 76800
#define START_LENGTH 38400
#define START_WIDTH 240
#define START_HEIGHT 160

#endif

