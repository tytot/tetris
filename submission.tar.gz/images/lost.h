/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 lost lost.png 
 * Time-stamp: Tuesday 04/05/2022, 03:01:27
 * 
 * Image Information
 * -----------------
 * lost.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef LOST_H
#define LOST_H

extern const unsigned short lost[38400];
#define LOST_SIZE 76800
#define LOST_LENGTH 38400
#define LOST_WIDTH 240
#define LOST_HEIGHT 160

#endif

