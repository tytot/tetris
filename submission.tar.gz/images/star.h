/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 star star.png 
 * Time-stamp: Tuesday 04/05/2022, 03:32:22
 * 
 * Image Information
 * -----------------
 * star.png 11@11
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef STAR_H
#define STAR_H

extern const unsigned short star[121];
#define STAR_SIZE 242
#define STAR_LENGTH 121
#define STAR_WIDTH 11
#define STAR_HEIGHT 11

#endif

